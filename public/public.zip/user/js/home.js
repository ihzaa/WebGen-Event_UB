$(document).ready(function () {
    $("#seachByCat").select2();
});
