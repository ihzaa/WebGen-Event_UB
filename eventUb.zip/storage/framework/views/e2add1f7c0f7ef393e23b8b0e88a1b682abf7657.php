

<?php $__env->startSection('title','Kelola Event'); ?>

<?php $__env->startSection('css_after'); ?>
<!-- DataTables -->
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('admin/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')); ?>">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
<li class="breadcrumb-item active">Kelola Event</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Kategori Event</h3>
                <div class="card-tools">
                    <!-- Buttons, labels, and many other things can be placed here! -->
                    <!-- Here is a label for example -->
                    <button class="btn btn-sm btn-primary" id="btn_trigger_kategori"><i class="fas fa-plus"></i> Tambah
                        Katergori</button>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="tabelkategori" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jumlah Event</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jumlah Event</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <!-- /.card-body -->
            <div id="kategoriloading" class="overlay dark">
                <i class="fas fa-2x fa-sync-alt fa-spin"></i>
            </div>
        </div>
        <!-- /.card -->
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Event</h3>
                <div class="card-tools">
                    <!-- Buttons, labels, and many other things can be placed here! -->
                    <!-- Here is a label for example -->
                    <a class="btn btn-sm btn-primary" id="btn_trigger_event"
                        href="<?php echo e(route('admin_tambah_event_get')); ?>"><i class="fas fa-plus"></i>
                        Tambah
                        Event</a>
                </div>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <table id="tabelevent" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Poster</th>
                            <th>Tanggal</th>
                            <th>Kategori</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                    <tfoot>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Poster</th>
                            <th>Tanggal</th>
                            <th>Kategori</th>
                            <th>Action</th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <div class="card-footer">
                Keterangan:
                <div class="row">
                    <div class="col-sm-6"><i class="fas fa-square text-dark"></i> : Waktu Event
                        Sudah Berlalu</div>
                    <div class="col-sm-6"><i class="far fa-square text-dark"></i> : Waktu Event
                        Masih Belum Terlewat</div>

                </div>
            </div>
            <!-- /.card-body -->
            <div id="eventloading" class="overlay dark">
                <i class="fas fa-2x fa-sync-alt fa-spin"></i>
            </div>
        </div>
        <!-- /.card -->
    </div>
</div>

<div id="modal_kategori" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modal_kategori_title">Title</h5>
                <button class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <label for="exampleInputEmail1">Nama Kategori</label>
                    <input type="text" class="form-control" id="nama_kategori_input"
                        placeholder="Masukkan Nama Kategori">
                    <span id="nama_kategori_input_error" class="error invalid-feedback">Form tidak boleh
                        kosong!</span>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-sm btn-success ml-auto" id="btn_simpan_modal_category"><i
                        class="fa fa-check"></i> Simpan</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>
<!-- DataTables -->
<script src="<?php echo e(asset('admin/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/dataTables.responsive.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/plugins/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"
    integrity="sha512-qTXRIMyZIFb8iQcfjXWCO8+M5Tbc38Qi5WzdPOYZHIlZpzBHG3L3by84BBBOiRGiEb7KKtAOAs5qYdUiZiQNNQ=="
    crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/locale/id.min.js"
    integrity="sha512-he8U4ic6kf3kustvJfiERUpojM8barHoz0WYpAUDWQVn61efpm3aVAD8RWL8OloaDDzMZ1gZiubF9OSdYBqHfQ=="
    crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/lazyload@2.0.0-rc.2/lazyload.js"></script>
<script>
    const URL = {getCat : "<?php echo e(route('admin_get_all_category_with_event_count')); ?>",
                insertCar : "<?php echo e(route('admin_tambah_category')); ?>",
                editCat : "<?php echo e(route('admin_edit_category',['id'=>'__asd'])); ?>",
                deleteCat : "<?php echo e(route('admin_delete_category')); ?>",
                getEvent : "<?php echo e(route('admin_get_all_event')); ?>",
                delEvent : "<?php echo e(route('admin_delete_event')); ?>",
                editEvent : "<?php echo e(route('admin_edit_event_get',['id'=>'astaga'])); ?>"
                }
    var storagePath = "<?php echo asset(''); ?>";
</script>
<script src="<?php echo e(asset('admin/dist/js/pages/kelolaEventCategory.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/js/pages/kelolaEventEvent.js')); ?>"></script>
<?php if(Session::get('icon')): ?>
<script>
    Swal.fire({
            icon: "<?php echo e(Session::get('icon')); ?>",
            title: "<?php echo e(Session::get('title')); ?>",
            text: "<?php echo e(Session::get('message')); ?>",
        });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kedai Website\projek 1\eventUb\resources\views/admin/kelolaEvent.blade.php ENDPATH**/ ?>