<footer class="text-muted">
    <div class="container">
        <p class="float-right">
            <a href="#" onclick="ScrollTo('start')">Kembali ke Atas</a>
        </p>

        <p>Develop with <i style="color: red;" class="fas fa-heart"></i> by <a href="">Kedai Website</a></p>
    </div>
</footer>